package pack2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Lab7_1_Lab3_Chrome {

	public static String driverPath = "D:\\Selenium\\M3 Selenium Installations\\Selenium Installations\\";

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver", driverPath
				+ "chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		// open url
		driver.get("http://demo.opencart.com/");
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();

		// PART 1 : LAUNCH APPLICATION
		// title check
		boolean title = driver.getTitle().equals("The OpenCart demo store");
		if (title)
			System.out.println("The OpenCart demo store");
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		// my account
		driver.findElement(By.cssSelector(".caret")).click();
		// register
		driver.findElement(
				By.cssSelector("a[href='https://demo.opencart.com/index.php?route=account/register']"))
				.click();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		// register heading
		WebElement heading = driver.findElement(By.cssSelector("#content>h1"));
		boolean b1 = heading.getText().equals("Register Account");
		if (b1)
			System.out.println("Register Account");

		// continue
		WebElement cont = driver
				.findElement(By.cssSelector(".btn.btn-primary"));
		cont.click();
		// verify warning message
		Thread.sleep(5000);
		WebElement warning = driver.findElement(By
				.cssSelector(".alert.alert-danger"));
		boolean b2 = warning.getText().contains(
				"Warning: You must agree to the Privacy Policy!");
		if (b2)
			System.out
					.println("Warning: You must agree to the Privacy Policy!");

		// PART 2 : For 'Your Personal Details'
		// first name 33 characters
		driver.findElement(By.cssSelector("#input-firstname")).sendKeys(
				"Srinivasuabcdefghijklmnopqrtstuvwx");
		driver.findElement(By.cssSelector(".btn.btn-primary")).click();
		Thread.sleep(2000);
		WebElement fnerror = driver.findElement(By
				.xpath("//*[@id='account']/div[2]/div/div"));
		boolean b3 = fnerror.getText().equals(
				"First Name must be between 1 and 32 characters!");
		if (b3)
			System.out
					.println("First Name must be between 1 and 32 characters!");
		WebElement fn = driver.findElement(By.cssSelector("#input-firstname"));
		fn.clear();
		fn.sendKeys("Srinivasu");

		// last name 33 characters
		driver.findElement(By.cssSelector("#input-lastname")).sendKeys(
				"Kalaabcdefghijklmnopqrtstuvwxyzabc");
		driver.findElement(By.cssSelector(".btn.btn-primary")).click();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		Thread.sleep(2000);
		WebElement lnerror = driver.findElement(By
				.xpath("//*[@id='account']/div[3]/div/div"));
		boolean b4 = lnerror.getText().equals(
				"Last Name must be between 1 and 32 characters!");
		if (b4)
			System.out
					.println("Last Name must be between 1 and 32 characters!");
		WebElement ln = driver.findElement(By.cssSelector("#input-lastname"));
		ln.clear();
		ln.sendKeys("Kala");

		driver.findElement(By.cssSelector("#input-email")).sendKeys(
				"srinivasu8.97@gmail.com");
		driver.findElement(By.cssSelector("#input-telephone")).sendKeys(
				"8985053099");

		// PART 3 : For 'Your Address'
		driver.findElement(By.cssSelector("#input-address-1")).sendKeys(
				"Akshay Tech Park");
		driver.findElement(By.cssSelector("#input-city")).sendKeys("Bangalore");
		driver.findElement(By.cssSelector("#input-postcode"))
				.sendKeys("560066");
		// country india
		WebElement country = driver.findElement(By
				.cssSelector("#input-country"));
		Select sel = new Select(country);
		sel.selectByVisibleText("India");

		// state karnataka
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		// Thread.sleep(6000);
		WebElement state = driver.findElement(By.cssSelector("#input-zone"));
		Select sel2 = new Select(state);
		sel2.selectByVisibleText("Karnataka");

		// PART 4 : For 'Password'
		// password
		driver.findElement(By.cssSelector("#input-password")).sendKeys("54395");
		driver.findElement(By.cssSelector("#input-confirm")).sendKeys("54395");

		// PART 4 : For 'Newsletter'
		// newsletter
		driver.findElement(
				By.cssSelector("input[type='radio'][value='1'][name='newsletter']"))
				.click();
		driver.findElement(By.cssSelector("input[type='checkbox']")).click();

		// click to continue
		driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]"))
				.click();

		boolean acccreated = driver
				.findElement(By.xpath("//*[@id='content']/h1")).getText()
				.contentEquals("Your Account Has Been Created!");

		if (acccreated)
			System.out.println("Your account has been Created");
		else
			System.out.println("Your account has not been Created");

		driver.findElement(By.xpath("//*[@id='content']/div/div/a")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@id='content']/ul[2]/li[1]/a"))
				.click();

	}
}