package pack2;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Lab6_2_Lab3_TestNG {

	public WebDriver driver;

	@BeforeClass
	public void beforeClass() {
		driver = new FirefoxDriver();

	}

	@BeforeMethod
	public void beforeMethod() {
		System.out.println("Before Method");
		driver.get("http://demo.opencart.com/");
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	@Test(priority = 1)
	public void Lab3() throws InterruptedException {

		// PART 1 : LAUNCH APPLICATION
		// title check

		Assert.assertEquals(driver.getTitle(), "The OpenCart demo store");

		driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
		// my account
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a/i"))
				.click();
		// register
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[1]/a"))
				.click();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		// register heading
		WebElement heading = driver.findElement(By
				.xpath("//*[@id='content']/h1"));
		Assert.assertEquals(heading.getText(), "Register Account");

		// continue
		WebElement cont = driver.findElement(By
				.xpath("//*[@id='content']/form/div/div/input[2]"));
		cont.click();
		// verify warning message
		Thread.sleep(3000);
		WebElement warning = driver.findElement(By
				.cssSelector(".alert.alert-danger"));
		boolean b2 = warning.getText().contains(
				"Warning: You must agree to the Privacy Policy!");
		if (b2)
			System.out
					.println("Warning: You must agree to the Privacy Policy!");

		// PART 2 : For 'Your Personal Details'
		// first name 33 characters
		driver.findElement(By.cssSelector("#input-firstname")).sendKeys(
				"Srinivasuabcdefghijklmnopqrtstuvwx");
		driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]"))
				.click();
		Thread.sleep(2000);
		WebElement fnerror = driver.findElement(By
				.xpath("//*[@id='account']/div[2]/div/div"));
		Assert.assertEquals(fnerror.getText(),
				"First Name must be between 1 and 32 characters!");
		WebElement fn = driver.findElement(By.cssSelector("#input-firstname"));
		fn.clear();
		fn.sendKeys("Srinivasu");

		// last name 33 characters
		driver.findElement(By.id("input-lastname")).sendKeys(
				"Kalaabcdefghijklmnopqrtstuvwxyzabc");
		driver.findElement(By.xpath("//*[@id='content']/form/div/div/input[2]"))
				.click();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		Thread.sleep(2000);
		WebElement lnerror = driver.findElement(By
				.xpath("//*[@id='account']/div[3]/div/div"));
		Assert.assertEquals(lnerror.getText(),
				"Last Name must be between 1 and 32 characters!");
		WebElement ln = driver.findElement(By.id("input-lastname"));
		ln.clear();
		ln.sendKeys("Kala");

		driver.findElement(By.id("input-email")).sendKeys(
				"srinivasu8.97@gmail.com");
		driver.findElement(By.cssSelector("#input-telephone")).sendKeys(
				"8985053099");

		// PART 3 : For 'Your Address'
		driver.findElement(By.cssSelector("#input-address-1")).sendKeys(
				"Akshay Tech Park");
		driver.findElement(By.cssSelector("#input-city")).sendKeys("Bangalore");
		driver.findElement(By.cssSelector("#input-postcode"))
				.sendKeys("560066");
		// country india
		WebElement country = driver.findElement(By.id("input-country"));
		Select sel = new Select(country);
		sel.selectByVisibleText("India");
		// print India
		WebElement select = driver.findElement(By.id("input-country"));
		List<WebElement> options = select.findElements(By.tagName("option"));

		for (WebElement option : options) {

			if ("India".equals(option.getText().trim()))

				System.out.println("India");
		}

		// state karnataka
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		// Thread.sleep(6000);
		WebElement state = driver.findElement(By.id("input-zone"));
		Select sel2 = new Select(state);
		sel2.selectByVisibleText("Karnataka");
		// print karnataka
		WebElement select2 = driver.findElement(By.id("input-zone"));
		List<WebElement> options2 = select2.findElements(By.tagName("option"));

		for (WebElement option : options2) {

			if ("Karnataka".equals(option.getText().trim()))

				System.out.println("Karnataka");
		}

		// sel2.selectByVisibleText("Karnataka");

		// PART 4 : For 'Password'
		// password
		driver.findElement(By.cssSelector("#input-password")).sendKeys("54395");
		driver.findElement(By.cssSelector("#input-confirm")).sendKeys("54395");

		// PART 4 : For 'Newsletter'
		// newsletter
		driver.findElement(
				By.xpath("//*[@id='content']/form/fieldset[4]/div/div/label[1]/input"))
				.click();
		driver.findElement(By.cssSelector(".pull-right>input")).click();

		// click to continue

		/*
		 * .findElement(By.xpath("//*[@id='content']/form/div/div/input[2]"))
		 * .click();
		 * 
		 * boolean acccreated = driver
		 * .findElement(By.xpath("//*[@id='content']/h1")).getText()
		 * .contentEquals("Your Account Has Been Created!");
		 * 
		 * if (acccreated) System.out.println("Your account has been Created");
		 * else System.out.println("Your account has not been Created");
		 * 
		 * driver.findElement(By.xpath("//*[@id='content']/div/div/a")).click();
		 * Thread.sleep(1000);
		 * driver.findElement(By.xpath("//*[@id='content']/ul[2]/li[1]/a"))
		 * .click();
		 */

	}

	@Test(priority = 2)
	public void Lab4() throws InterruptedException {

		// my account
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a/i"))
				.click();
		// login
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[2]/a"))
				.click();
		// email
		driver.findElement(By.xpath("//*[@id='input-email']")).sendKeys(
				"srinivasu958@gmail.com");
		// password
		driver.findElement(By.xpath("//*[@id='input-password']")).sendKeys(
				"543958srinu");
		// submit login
		driver.findElement(
				By.xpath("//*[@id='content']/div/div[2]/div/form/input"))
				.click();
		// components
		driver.findElement(By.xpath("//*[@id='menu']/div[2]/ul/li[3]/a"))
				.click();
		// monitor
		driver.findElement(
				By.xpath("//*[@id='menu']/div[2]/ul/li[3]/div/div/ul/li[2]/a"))
				.click();
		// 15 to 25
		WebElement show = driver
				.findElement(By.xpath("//*[@id='input-limit']"));
		Select sel = new Select(show);
		sel.selectByVisibleText("25");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// add to cart
		driver.findElement(
				By.xpath("//*[@id='content']/div[3]/div[1]/div/div[2]/div[2]/button[1]"))
				.click();
		Thread.sleep(6000);

		/*
		 * driver.findElement(
		 * By.xpath("//*[@id='content']/div[1]/div[1]/ul[2]/li[2]/a")) .click();
		 */

		// specification
		// driver.findElement(By.xpath("//a[@href='#tab-specification']")).click();
		// driver.findElement(By.linkText("Specification")).click();
		// driver.get("http://demo.opencart.com/index.php?route=product/product&product_id=42");
		driver.findElement(By.xpath("//a[@href='#tab-specification']")).click();
		Assert.assertEquals(
				driver.findElement(
						By.xpath("//*[@id='tab-specification']/table/thead/tr/td"))
						.getText(), "Processor");
		Assert.assertEquals(
				driver.findElement(
						By.xpath("//*[@id='tab-specification']/table/tbody/tr/td[1]"))
						.getText(), "Clockspeed");
		Assert.assertEquals(
				driver.findElement(
						By.xpath("//*[@id='tab-specification']/table/tbody/tr/td[2]"))
						.getText(), "100mhz");
		// add to wish list
		driver.findElement(
				By.xpath("//*[@id='content']/div[1]/div[2]/div[1]/button[1]"))
				.click();
		Thread.sleep(3000);
		// success message of apple cinema 30"
		WebElement success1 = driver.findElement(By
				.xpath("html/body/div[2]/div[1]"));
		boolean b3 = success1.getText().contains(
				"Success: You have added Apple Cinema 30\" to your wish list!");
		if (b3)
			System.out
					.println("Success: You have added Apple Cinema 30\" to your wish list!");
		else
			System.out.println(success1.getText());
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='search']/input")).sendKeys(
				"Mobile");
		// search
		driver.findElement(By.xpath("//*[@id='search']/span/button")).click();
		driver.findElement(By.xpath("//*[@id='description']")).click();
		// htc touch hd link
		driver.findElement(By.xpath("//*[@id='button-search']")).click();
		// submit
		driver.findElement(
				By.xpath("//*[@id='content']/div[4]/div[1]/div/div[2]/h4/a"))
				.click();
		// 1 to 3
		WebElement q = driver
				.findElement(By.xpath("//*[@id='input-quantity']"));
		q.clear();
		q.sendKeys("3");
		// add to cart
		// add to cart
		driver.findElement(By.xpath("//*[@id='button-cart']")).click();
		// add to cart success message
		Thread.sleep(3000);
		WebElement success2 = driver.findElement(By
				.xpath("html/body/div[2]/div[1]"));
		boolean b4 = success2.getText().contains("");
		if (b4)
			System.out
					.println("Success: You have added HTC Touch HD to your shopping cart!");
		else
			System.out.println(success2.getText());
		Thread.sleep(3000);
		// view cart
		driver.findElement(By.xpath("//*[@id='cart']/button")).click();
		// check htc touch hd name
		Thread.sleep(2000);
		Assert.assertEquals(
				driver.findElement(
						By.xpath("//*[@id='cart']/ul/li[1]/table/tbody/tr/td[2]/a"))
						.getText(), "HTC Touch HD");
		// checkout
		WebElement co = driver.findElement(By
				.xpath("//*[@id='cart']/ul/li[2]/div/p/a[2]/strong"));

		boolean b6 = co.getText().contains("Checkout");
		if (b6)
			System.out.println("Checkout");
		co.click();
		Thread.sleep(2000);
		// my account
		// delay
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a")).click();
		// Logout
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[5]/a"))
				.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// title

		Assert.assertEquals(
				driver.findElement(By.xpath("//*[@id='content']/h1")).getText(),
				"Account Logout");
		// continue
		driver.findElement(By.cssSelector(".btn.btn-primary")).click();

		driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
	}

	@AfterMethod
	public void afterMethod() {
		System.out.println("After Method");
	}

	@AfterClass
	public void afterClass() {
		driver.close();
	}
}