package pack2;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

public class Lab8_1_Lab4_Firefox {
	public static void main(String args[]) throws MalformedURLException {

		// Program execution on Firefox Browser
		DesiredCapabilities capability = DesiredCapabilities.firefox();
		
		// Setting Browser Name to firefox
		capability.setBrowserName("firefox");

		// Setting Platform
		capability.setPlatform(Platform.ANY);

		WebDriver driver = new RemoteWebDriver(new URL(
				"http://localhost:4444/wd/hub"), capability);

		try {
			driver.get("http://demo.opencart.com/");
			driver.manage().window().maximize();
			// my account
			driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a/i"))
					.click();
			// login
			driver.findElement(
					By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[2]/a"))
					.click();
			// email
			driver.findElement(By.xpath("//*[@id='input-email']")).sendKeys(
					"srinivasu958@gmail.com");
			// password
			driver.findElement(By.xpath("//*[@id='input-password']")).sendKeys(
					"543958srinu");
			// submit login
			driver.findElement(
					By.xpath("//*[@id='content']/div/div[2]/div/form/input"))
					.click();
			// components
			driver.findElement(By.xpath("//*[@id='menu']/div[2]/ul/li[3]/a"))
					.click();
			// monitor
			driver.findElement(
					By.xpath("//*[@id='menu']/div[2]/ul/li[3]/div/div/ul/li[2]/a"))
					.click();
			// 15 to 25
			WebElement show = driver.findElement(By
					.xpath("//*[@id='input-limit']"));
			Select sel = new Select(show);
			sel.selectByVisibleText("25");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			// add to cart
			driver.findElement(
					By.xpath("//*[@id='content']/div[3]/div[1]/div/div[2]/div[2]/button[1]"))
					.click();
			Thread.sleep(6000);

			/*
			 * driver.findElement(
			 * By.xpath("//*[@id='content']/div[1]/div[1]/ul[2]/li[2]/a"))
			 * .click();
			 */

			// specification
			// driver.findElement(By.xpath("//a[@href='#tab-specification']")).click();
			// driver.findElement(By.linkText("Specification")).click();
			// driver.get("http://demo.opencart.com/index.php?route=product/product&product_id=42");
			driver.findElement(By.xpath("//a[@href='#tab-specification']"))
					.click();
			boolean b = driver
					.findElement(
							By.xpath("//*[@id='tab-specification']/table/thead/tr/td"))
					.getText().contentEquals("Processor");
			if (b)
				System.out.println("Processor");
			boolean b1 = driver
					.findElement(
							By.xpath("//*[@id='tab-specification']/table/tbody/tr/td[1]"))
					.getText().contentEquals("Clockspeed");
			if (b1)
				System.out.println("Clockspeed");
			boolean b2 = driver
					.findElement(
							By.xpath("//*[@id='tab-specification']/table/tbody/tr/td[2]"))
					.getText().contentEquals("100mhz");
			if (b2)
				System.out.println("100mhz");
			// add to wish list
			driver.findElement(
					By.xpath("//*[@id='content']/div[1]/div[2]/div[1]/button[1]"))
					.click();
			Thread.sleep(3000);
			// success message of apple cinema 30"
			WebElement success1 = driver.findElement(By
					.xpath("html/body/div[2]/div[1]"));
			boolean b3 = success1
					.getText()
					.contains(
							"Success: You have added Apple Cinema 30\" to your wish list!");
			if (b3)
				System.out
						.println("Success: You have added Apple Cinema 30\" to your wish list!");
			else
				System.out.println(success1.getText());
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[@id='search']/input")).sendKeys(
					"Mobile");
			// search
			driver.findElement(By.xpath("//*[@id='search']/span/button"))
					.click();
			driver.findElement(By.xpath("//*[@id='description']")).click();
			// htc touch hd link
			driver.findElement(By.xpath("//*[@id='button-search']")).click();
			// submit
			driver.findElement(
					By.xpath("//*[@id='content']/div[4]/div[1]/div/div[2]/h4/a"))
					.click();
			// 1 to 3
			WebElement q = driver.findElement(By
					.xpath("//*[@id='input-quantity']"));
			q.clear();
			q.sendKeys("3");
			// add to cart
			// add to cart
			driver.findElement(By.xpath("//*[@id='button-cart']")).click();
			// add to cart success message

			Thread.sleep(3000);
			WebElement success2 = driver.findElement(By
					.xpath("html/body/div[2]/div[1]"));
			boolean b4 = success2.getText().contains("");
			if (b4)
				System.out
						.println("Success: You have added HTC Touch HD to your shopping cart!");
			else
				System.out.println(success2.getText());
			Thread.sleep(3000);
			// view cart
			driver.findElement(By.xpath("//*[@id='cart']/button")).click();
			// check htc touch hd name
			Thread.sleep(1000);
			boolean b5 = driver
					.findElement(
							By.xpath("//*[@id='cart']/ul/li[1]/table/tbody/tr/td[2]/a"))
					.getText().contentEquals("HTC Touch HD");
			if (b5)
				System.out.println("HTC Touch HD");

			// checkout
			WebElement co = driver.findElement(By
					.xpath("//*[@id='cart']/ul/li[2]/div/p/a[2]/strong"));

			boolean b6 = co.getText().contains("Checkout");

			if (b6)
				System.out.println("Checkout");
			co.click();
			Thread.sleep(2000);
			// my account
			// delay
			driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a"))
					.click();
			// Logout
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.findElement(
					By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[5]/a"))
					.click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			// title
			boolean heading = driver
					.findElement(By.xpath("//*[@id='content']/h1")).getText()
					.contentEquals("Account Logout");
			if (heading)
				System.out.println("Account Logout");
			// continue
			driver.findElement(By.cssSelector(".btn.btn-primary")).click();
			driver.close();

		} catch (Exception e) {
			System.out.println("Please run the code again");
		}

	}
}
