package pack2;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

public class Lab8_1_Lab3_Chrome {

	public static String driverPath = "C:\\selenium lib\\";

	public static void main(String args[]) throws MalformedURLException {

		// Program execution on Chrome Browser
		System.setProperty("webdriver.chrome.driver", driverPath
				+ "chromedriver.exe");
		DesiredCapabilities capability = DesiredCapabilities.chrome();

		// Setting Browser Name to Chrome
		capability.setBrowserName("chrome");

		// Setting Platform
		capability.setPlatform(Platform.ANY);

		WebDriver driver = new RemoteWebDriver(new URL(
				"http://localhost:4444/wd/hub"), capability);

		try {

			// PART 1 : LAUNCH APPLICATION
			// title check
			boolean title = driver.getTitle().equals("The OpenCart demo store");
			if (title)
				System.out.println("The OpenCart demo store");
			driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);
			// my account
			driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a/i"))
					.click();
			// register
			driver.findElement(
					By.xpath("//*[@id='top-links']/ul/li[2]/ul/li[1]/a"))
					.click();
			// register heading
			WebElement heading = driver.findElement(By
					.xpath("//*[@id='content']/h1"));
			boolean b1 = heading.getText().equals("Register Account");
			if (b1)
				System.out.println("Register Account");

			// continue
			WebElement cont = driver.findElement(By
					.xpath("//*[@id='content']/form/div/div/input[2]"));
			cont.click();
			// verify warning message
			Thread.sleep(3000);
			WebElement warning = driver.findElement(By
					.cssSelector(".alert.alert-danger"));
			boolean b2 = warning.getText().contains(
					"Warning: You must agree to the Privacy Policy!");
			if (b2)
				System.out
						.println("Warning: You must agree to the Privacy Policy!");

			// PART 2 : For 'Your Personal Details'
			// first name 33 characters
			driver.findElement(By.cssSelector("#input-firstname")).sendKeys(
					"Srinivasuabcdefghijklmnopqrtstuvwx");
			driver.findElement(
					By.xpath("//*[@id='content']/form/div/div/input[2]"))
					.click();
			Thread.sleep(2000);
			WebElement fnerror = driver.findElement(By
					.xpath("//*[@id='account']/div[2]/div/div"));
			boolean b3 = fnerror.getText().equals(
					"First Name must be between 1 and 32 characters!");
			if (b3)
				System.out
						.println("First Name must be between 1 and 32 characters!");
			WebElement fn = driver.findElement(By
					.cssSelector("#input-firstname"));
			fn.clear();
			fn.sendKeys("Srinivasu");

			// last name 33 characters
			driver.findElement(By.id("input-lastname")).sendKeys(
					"Kalaabcdefghijklmnopqrtstuvwxyzabc");
			driver.findElement(
					By.xpath("//*[@id='content']/form/div/div/input[2]"))
					.click();
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			Thread.sleep(2000);
			WebElement lnerror = driver.findElement(By
					.xpath("//*[@id='account']/div[3]/div/div"));
			boolean b4 = lnerror.getText().equals(
					"Last Name must be between 1 and 32 characters!");
			if (b4)
				System.out
						.println("Last Name must be between 1 and 32 characters!");
			WebElement ln = driver.findElement(By.id("input-lastname"));
			ln.clear();
			ln.sendKeys("Kala");

			driver.findElement(By.id("input-email")).sendKeys(
					"srinivasu8.97@gmail.com");
			driver.findElement(By.cssSelector("#input-telephone")).sendKeys(
					"8985053099");

			// PART 3 : For 'Your Address'
			driver.findElement(By.cssSelector("#input-address-1")).sendKeys(
					"Akshay Tech Park");
			driver.findElement(By.cssSelector("#input-city")).sendKeys(
					"Bangalore");
			driver.findElement(By.cssSelector("#input-postcode")).sendKeys(
					"560066");
			// country india
			WebElement country = driver.findElement(By.id("input-country"));
			Select sel = new Select(country);
			sel.selectByVisibleText("India");
			// print India
			WebElement select = driver.findElement(By.id("input-country"));
			List<WebElement> options = select
					.findElements(By.tagName("option"));

			for (WebElement option : options) {

				if ("India".equals(option.getText().trim()))

					System.out.println("India");
			}

			// state karnataka
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			// Thread.sleep(6000);
			WebElement state = driver.findElement(By.id("input-zone"));
			Select sel2 = new Select(state);
			sel2.selectByVisibleText("Karnataka");
			// print karnataka
			WebElement select2 = driver.findElement(By.id("input-zone"));
			List<WebElement> options2 = select2.findElements(By
					.tagName("option"));

			for (WebElement option : options2) {

				if ("Karnataka".equals(option.getText().trim()))

					System.out.println("Karnataka");
			}

			// sel2.selectByVisibleText("Karnataka");

			// PART 4 : For 'Password'
			// password
			driver.findElement(By.cssSelector("#input-password")).sendKeys(
					"54395");
			driver.findElement(By.cssSelector("#input-confirm")).sendKeys(
					"54395");

			// PART 4 : For 'Newsletter'
			// newsletter
			driver.findElement(
					By.xpath("//*[@id='content']/form/fieldset[4]/div/div/label[1]/input"))
					.click();
			driver.findElement(By.cssSelector(".pull-right>input")).click();

			// click to continue

			driver.findElement(
					By.xpath("//*[@id='content']/form/div/div/input[2]"))
					.click();

			boolean acccreated = driver
					.findElement(By.xpath("//*[@id='content']/h1")).getText()
					.contentEquals("Your Account Has Been Created!");

			if (acccreated)
				System.out.println("Your account has been Created");
			else
				System.out.println("Your account has not been Created");

			driver.findElement(By.xpath("//*[@id='content']/div/div/a"))
					.click();
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id='content']/ul[2]/li[1]/a"))
					.click();

		} catch (Exception e) {
			System.out.println("Please run the app once again");
		}
	}

}
